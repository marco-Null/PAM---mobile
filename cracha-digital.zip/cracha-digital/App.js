import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Alert,
  Image,
  TextInput,
  ScrollView,
} from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

import React, { useState } from 'react';

import * as ImagePicker from 'expo-image-picker';

import DateTimePicker from '@react-native-community/datetimepicker';

export default function App() {
  const [imagem, setImagem] = useState(null);
  const [nomeUser, setNomeUser] = useState(null);
  const [rm, setRm] = useState(null);
  const [enviado, setEnviado] = useState(false);
  const [dataNascimento, setDataNascimento] = useState(new Date());
  const [mostrarData, setMostrarData] = useState(false);

  const escolherImagem = async () => {
    const permissao = await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (!permissao.granted) {
      Alert.alert(
        'Permissão negada!',
        'Precisamos da sua permissão para acessar sua galeria'
      );
      return;
    }

    const resultadoImagem = await ImagePicker.launchImageLibraryAsync({
      midiaTypes: ['images'],
      allowsEditing: true,
      quality: 1,
    });

    if (!resultadoImagem.canceled) {
      setImagem(resultadoImagem.assets[0].uri);
    }
  };

  const escolherData = () => {
    setMostrarData(true);
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.conteudo}>
      <Text style={styles.paragraph}>Crachá digital radical</Text>

      <Text style={styles.textoEscolherImagem}> Adicione sua imagem </Text>

      {imagem && (
        <Image source={{ uri: imagem }} style={styles.imagemSelecao} />
      )}

      <TouchableOpacity onPress={escolherImagem} style={styles.botaoEnviar}>
        <Text style={styles.textoBotaoEnviar}> Adicionar imagem </Text>
      </TouchableOpacity>

      <Text style={styles.nomeUsuarioTexto}> Nome de usuario </Text>

      <TextInput
        style={styles.botaoEscreverNome}
        placeholder="Digite seu nome"
        placeholderTextColor="black"
        value={nomeUser}
        onChangeText={setNomeUser}
      />

      <Text style={styles.nomeUsuarioTexto}> RM </Text>

      <TextInput
        style={styles.botaoEscreverNome}
        placeholder="Digite seu RM"
        placeholderTextColor="black"
        value={rm}
        onChangeText={setRm}
      />

      <Text style={styles.nomeUsuarioTexto}> Data de nascimento </Text>

      <TouchableOpacity onPress={escolherData} style={styles.botaoEscreverNome}>
        <Text style={{ textAlign: 'center', fontSize: 13 }}>
          {dataNascimento.toLocaleDateString('pt-BR')}
        </Text>
      </TouchableOpacity>

      {mostrarData && (
        <DateTimePicker
          value={dataNascimento}
          mode="date"
          display="default"
          onChange={(event, date) => {
            setMostrarData(false);
            if (date) {
              setDataNascimento(date);
            }
          }}
        />
      )}

      <TouchableOpacity style={styles.finalbotaoEnviarTudo} onPress={() => setEnviado(true)}>
        <Text style={{ color: 'white', fontSize: 20 }}> Enviar </Text>
      </TouchableOpacity>

      {enviado && (
        <View style={styles.container2}>
          {imagem && (
            <Image source={{ uri: imagem }} style={styles.imagemCracha} />
          )}

          <Text style={styles.textoCracha}>Nome: {nomeUser}</Text>

          <Text style={styles.textoCracha}>RM: {rm}</Text>

          <Text style={styles.textoCracha}>
            Data de nascimento: {dataNascimento.toLocaleDateString('pt-BR')}
          </Text>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },

  conteudo: {
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 50,
  },

  container2: {
    backgroundColor: 'white',
    height: 300,
    borderRadius: 30,
    justifyContent: 'center',
  },

  imagemCracha: {
    width: 150,
    height: 150,
    borderRadius: 70,
    alignSelf: 'center',
    marginBottom: 15,
  },

  textoCracha: {
    color: 'black',
    fontSize: 20,
    marginBottom: 8,
    textAlign: 'center',
  },

  paragraph: {
    marginTop: 50,
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
    alignItems: 'top',
    color: 'white',
  },

  textoEscolherImagem: {
    textAlign: 'center',
    fontWeight: 'bold',
    justifyContent: 'start',
    alignItems: 'top',
    color: 'white',
    margin: 20,
  },

  textoBotaoEnviar: {
    color: 'white',
    textAlign: 'center',
    fontSize: 12,
    fontWeight: 'bold',
  },

  botaoEnviar: {
    backgroundColor: 'green',
    color: 'white',
    justifyContent: 'center',
    width: 150,
    height: 30,
    borderRadius: 20,
    alignSelf: 'center',
    marginBottom: 20,
  },

  imagemSelecao: {
    width: 100,
    height: 100,
    marginBottom: 25,
    borderRadius: 5,
    alignSelf: 'center',
  },

  nomeUsuarioTexto: {
    color: 'white',
    textAlign: 'center',
    fontSize: 15,
    margin: 10,
  },

  botaoEscreverNome: {
    height: 35,
    width: 300,
    backgroundColor: 'white',
    alignSelf: 'center',
    justifyContent: 'center',
    fontSize: 13,
    borderRadius: 20,
    padding: 10,
    textAlign: 'center',
    marginBottom: 20,
  },

  finalbotaoEnviarTudo: {
    backgroundColor: 'green',
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    height: 40,
    width: 150,
    borderRadius: 15,
    marginBottom: 20,
  },
});
