import { StyleSheet, Text, View, TextInput, TouchableOpacity } from 'react-native';

import React, { useState, useEffect } from 'react';

import StorageAsync from '@react-native-async-storage/async-storage';

export default function App() {
  const [tarefa, setTarefa] = useState();
  const [armazem, setArmazem] = useState();

  const salvarTaf = async () => {
    try {
      await StorageAsync.setItem('tarefa:chave', tarefa);
      alert('Salvo!');
    } catch (e) {
      alert('Erro!: '.e);
    }
  };

  const carregarTaf = async () => {
    try {
      const valor = await StorageAsync.getItem('tarefa:chave');
      if (valor != null) {
        setArmazem(valor);
      }
    } catch (e) {
      alert('Erro!: '.e);
    }
  };

  const deletarTaf = async () => {
    try{
      await StorageAsync.removeItem('tarefa:chave');
      setArmazem('');
      alert("Item removido!");
    }
    catch (e){
      alert("Erro ao excluir tarefa!: " . e);
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.textoTitulo}> ToDo LIST-TEC </Text>
      <TextInput
        style={styles.input}
        placeholder="Digite algo"
        onChangeText={setTarefa}
        value={tarefa}
      />
      <TouchableOpacity onPress={salvarTaf} style={styles.btn1}> 
        <Text style={{color: 'black', textAlign: 'center', marginTop: 0,
        fontSize: 20,}}> Salvar </Text>  
      </TouchableOpacity>
      <TouchableOpacity onPress={carregarTaf} style={styles.btn2}>
        <Text style={{color: 'black', textAlign: 'center', marginTop: 0,
        fontSize: 20,}}> Carregar </Text>  
      </TouchableOpacity> 
      <TouchableOpacity onPress={deletarTaf} style={styles.btn3}>
        <Text style={{color: 'white', textAlign: 'center', marginTop: 0,
        fontSize: 20,}}> Deletar </Text>  
      </TouchableOpacity> 

      <View style={styles.container2}>
        <Text style={styles.text}>Salvo: {armazem}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    justifyContent: 'center', 
    padding: 20,
    backgroundColor: 'black'
    },

  container2: { 
    justifyContent: 'center', 
    padding: 20,
    backgroundColor: 'white',
    height: 80,
    marginTop: 20,
    borderRadius: 20
    },

  input: { 
    borderWidth: 1, 
    borderColor: '#ccc', 
    marginBottom: 30,
    height: 55,
    padding: 8,
    color: 'white'
    },

  text: { 
    marginTop: 0, 
    fontSize: 20,
    fontStyle: 'italic',
    color: 'black',
    },

  textoTitulo:{
    color: 'white',
    textAlign: 'center',
    marginBottom: 40,
    fontSize: 35
  },

  btn1:{
    color: 'black',
    fontSize: 20,
    backgroundColor: 'lime',
    padding: 12,
    borderRadius: 30,
    alignItems: 'center',
    marginBottom: 10,
    height: 50
  },

  btn2:{
    backgroundColor: 'white',
    fontSize: 20,
    padding: 12,
    borderRadius: 30,
    alignItems: 'center',
    marginBottom: 10,
    height: 50
  },

  btn3:{
    backgroundColor: 'red',
    fontSize: 20,
    color: 'white',
    padding: 12,
    borderRadius: 30,
    alignItems: 'center',
    marginBottom: 10,
    height: 50
  }
});
